//   Question#1
var var1,var2,var3;

// Question#2
// 5 legal variable names
var firstName;
var sim1;
var alert1;
var var1;
var Rose;

// Question#3
// 5 illegal variable names
// var "name";
// var 5;
// var alert;
// var var;
// var first name;

// Question#4
// Display this in your browser 
// heading stating “Rules for naming JS variables”
// Variable names can only contain "numbers", "$", "_" and "-". For example $my_1stVariable
// Variables must begin with a "letter", "$" or "_". For example $name, _name or name
// Variable names are case "sensitive"
// Variable names should not be JS "keywords"


