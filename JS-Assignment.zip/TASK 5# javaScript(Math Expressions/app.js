//Question 1
// var number1=5;
// var number2=10;
// var sum=number1+number2;
// document.write(sum);

//Question 2
// var number1=5;
// var number2=10;

// var sum=number1+number2;
// console.log(sum);

// var multiplication=number1*number2;
// console.log(multiplication);

// var division =number1/number2;
// console.log(division);

// var modulus =number1%number2;
// console.log(modulus); 

//Question 3
// var value ;
// document.write('Value after variable declaration is:' +' '+value)
// var num = 10;
// document.write('initial value:'+' '+num)
// num++;
// document.write('increment value:'+' '+num)

// document.write("value after addition:", num+9 )
// num--;
// document.write('decrement value:'+' '+num)
// document.write("reminder:",num % 3)

//Question 4                             
// var ticket = 600;
// var totalTicketPice = ticket * 5;
// document.write('cost of 5 tickets is:'+' '+totalTicketPice+"PKR\n")

//Question 5
// alert("Table of 4\n4 x 1 = 4\n4 x 2 = 8\n4 x 3 = 12\n4 x 4 = 16\n4 x 5 = 20\n4 x 6 = 24\n4 x 7 = 28\n4 x 8 = 32\n4 x 9 = 36\n4 x 10 = 40\n")

//Question 6
// calculate fahrenheit
// const celsius = prompt("Enter a celsius value: ");


// const fahrenheit = (celsius * 1.8) + 32


// document.write(celcius,"C", " to ", fahrenheit,"C");

// calculate celsius
// const fahrenheit = prompt("Enter a celsius value: ");


// celsius = (fahrenheit - 32) / 1.8


// document.write(fahrenheit,"F"," to ", celsius,"C");


//Question 7
//  <h1>Shopping Cart </h1>
//  var item1 = 650
//  var item2 = 100
//  var qtyitem1 = 3
//  var qtyitem2 = 7
//  var charges = 100
//  var total = ((item1*qtyitem1)+(item2*qtyitem2)+charges)
 
//  document.write(
//      "<h1> Shopping Card </h1>"+
//      "price of item 1 is "+item1+
//      "<br/>Quantity of item 1 is "+qtyitem1+
//      "<br/> Price of item 2 is "+item2+
//      "<br/>Quantity of item 2 is "+qtyitem2+
//      "<br/>Shipping Charges" +charges+
//      "<br/> <br/> <br/>Total cost of your order is "+total
 
//  )

//Question 8
// var totalMarks = 980
// var marksObtained = 804
// var percentage = 804/980 *100

// document.write(
//     "<h1> Marks Sheet </h1>" +
//     "Total marks :" +totalMarks+
//     "<br/>Marks obtained :" +marksObtained+
//     " <br/> Percentage :" +percentage

// )


//Question 9
// var dollar = 104.80 * 10
// var sar = 28 * 25
// var pkr = dollar+sar 

// document.write("<h1> Currency in PKR </h1> Total Currency in PKR:" +pkr)

//Question 10
// var num = 1
// num = ((num+5)*10)/2

//Question 11
// var currentYear = 2020
// var birthYear = 1992
// var age = currentYear-birthYear
// document.write("<h1>Age Calculator</h1>currentYear: "+currentYear+"</br>birthYear: "+birthYear+"</br>currentage"+age)

//Question 12
// var radius = 20
// var circumference = 2 * 3.142 * radius
// var area = 3.142 * radius * radius

// document.write (
//     "<h1>The Geometrizer </h1>"
//     +"Radius of a circle :" +radius+
//     "<br/> The circumference is : "+circumference+
//     "<br/> The area is : "+area

// )

//Question 13
// var snack = "chocolate chip"
// var age = 15
// var maxAge = 65
// var amntPerDay = 3
// var total = (maxAge -age)*amntPerDay

// document.write(
//     "<h1> The Life Time Calculator</h1>" +
//     "Favourite Snack : "+snack+
//     "<br/> Current age: " +age+
//     "<br/> Estimated Maximum Age: "+maxAge+
//     "<br/> Amount old snacks Per day: "+amntPerDay+
//     "<br/> You will need: "+total+" "+snack+
//     "to last you untill the ripe old age of" +maxAge

// )
