// var city = prompt("Enter Your City Name").toLowerCase();

// if ( city === "Karachi"){
//     alert("Welcome to city of lights")
// }


// var gender = prompt("Enter Your Gender").toLowerCase();
// if  (gender === "Male"){
//     alert("Good Morning Sir")
// }

// if  (gender === "Female"){
//     alert("Good Morning Ma'am")
// }


// var light = prompt("Enter Traffic SIgnal Light Color").toLowerCase();
// if (light=== "Red"){
//     alert("Must Stop")
// }

// else if (light=== "Yellow"){
//    alert("Ready to move")
// }

// else (light=== "Green"){
//    alert("Move now")
// }



// var fuel = prompt("Enter Your Remaining Fuel Levl")
// if (fuel <= "0.25"){
//     alert("Please refill the fuel in your car")
// }
// else{
//     alert("enjoy your travel!")
// }

// var a = 4; 
// if (++a === 5){ 
//     alert("given condition for variable a is true");              //Running
// } 
 
// var b = 82; 
// if (b++ === 83){ 
//     alert("given condition for variable b is true");        //not working
//  } 

// var c = 12; 
// if (c++ === 13){ 
//     alert("condition 1 is true"); 
// }
//  if (c === 13){ 
//     alert("condition 2 is true");        //condition 2 and 4 is working
//  } 
//  if (++c < 14){ 
//     alert("condition 3 is true"); 
// } 
// if(c === 14){
//      alert("condition 4 is true");
//      } 




// var materialCost = 20000; 
// var laborCost = 2000; 
// var totalCost = materialCost + laborCost; 
// if (totalCost === laborCost + materialCost){         //working
//      alert("The cost equals"); 
//     } 

// if (true){
//      alert("True"); 
//     }                         //false condition not working
//     if (false){ 
//         alert("False"); 
//     }


// if("car" < "cat"){
//      alert("car is smaller than cat");      //working
//     } 



// var totalMarks = 300;
// var sub1 = prompt("Enter Your First Subject Marks")
// var sub2 = prompt("Enter Your Second Subject Marks")
// var sub3 = prompt("Enter Your Third Subject Marks")
// var sub1Marks = Number(sub1)
// var sub2Marks = Number(sub2)
// var sub3Marks = Number(sub3)
// var markObtained = sub1Marks+sub2Marks+sub3Marks
// var percentage = markObtained/totalMarks*100

// if (percentage >= 80){
//     grade = "A-one";
//     remarks = "Excellent";
// }

// if (percentage >= 70){
//     grade = "A";
//     remarks = "Good";
// }

// if (percentage >= 60){
//     grade = "B";
//     remarks = "You Need to improve";
// }
// if (percentage <= 60){
//     grade = "Fail";
//     remarks = "Sorry";
// }

// document.write(
//     "<h1>Marks sheet</h1>"+
//     "<br/>Total Marks :"+totalMarks+
//     "<br/>Marks Obtained :"+markObtained+
//     "<br/>Percentage :"+percentage+"%"+
//     "<br/>Grade :"+grade+
//     "<br/>Remarks :"+remarks

// )
 
// var number = 10
// var userInput = +prompt("Enter the number")
// if (number==userInput){
//     alert("BINGO! Correct Answer")
// }

// else if (userInput+1==number){
//     alert("Close enough to the correct answer")
// }

// else{
//     alert("You lost!")
// }

// var num = prompt("Enter a Number to check is divisible by 3")

// if (num % 3 === 0){
//     alert("Your Given Number is Divisible by 3")

// }else {
//     alert("Your Given Number is not Divisble by 3")
// }



// var num = prompt("Enter a number: ")
// if(num % 2 === 0){
//     alert(num +" is a even number")
// }else{
//     alert(num +" is a odd number")
// }

// var temp = prompt("Enter the temperature")
// var t = Number(temp)

// if (t > 40){
//     alert("It is too hot outside")
// }

// if (t > 30){
//     alert("The weather today is Normal")
// }

// if (t > 20){
//     alert("Today's weather is cool")
// }

// if (t > 10){
//     alert("OMG! Today's weather is a cool")
// }


// var a = prompt("Enter First number")
// var b = prompt("Enter Second number")
// var operator = prompt("Enter an operator operation(+,-,*,/,%)")
// var num1 = Number(a)
// var num2 = Number(b)

// if (operator === "+"){
//     alert ("Your Ans is "+(num1+num2))
// }

// else if (operator === "-"){
//     alert ("Your Ans is "+(num1-num2))
// }

// else if (operator === "*"){
//     alert ("Your Ans is "+(num1*num2))
// }

// else if (operator === "/"){
//     alert ("Your Ans is "+(num1/num2))
// }

// else if (operator === "%"){
//     alert ("Your Ans is "+(num1%num2))
// }
// else{
//     alert("please use given operators!")
// }

 
 
 

 
 